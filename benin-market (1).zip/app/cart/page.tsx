import type { Metadata } from "next"
import CartItems from "@/components/cart-items"
import CartSummary from "@/components/cart-summary"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ShoppingBag } from "lucide-react"

export const metadata: Metadata = {
  title: "Shopping Cart | Benin Market",
  description: "View and manage your shopping cart",
}

export default function CartPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Shopping Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <CartItems />
        </div>

        <div className="lg:col-span-1">
          <CartSummary />

          <div className="mt-6 text-center">
            <p className="text-sm text-muted-foreground mb-4">
              Need help? Contact our customer support at{" "}
              <Link href="/contact" className="text-primary hover:underline">
                support@beninmarket.com
              </Link>
            </p>

            <Button variant="outline" asChild className="w-full">
              <Link href="/products">
                <ShoppingBag className="mr-2 h-4 w-4" />
                Continue Shopping
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

