import type { Metadata } from "next"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export const metadata: Metadata = {
  title: "About Us | Benin Market",
  description: "Learn about Benin Market, our mission, and our team",
}

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">About Benin Market</h1>

        <div className="relative w-full h-[300px] md:h-[400px] rounded-lg overflow-hidden mb-8">
          <Image src="/images/marketplace.jpg" alt="Benin Market Marketplace" fill className="object-cover" />
        </div>

        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-bold mb-4">Our Story</h2>
            <p className="text-muted-foreground mb-4">
              Founded in 2020, Benin Market was created with a simple mission: to connect local sellers with customers
              across Benin and West Africa. What started as a small platform for artisans to sell their crafts has grown
              into a comprehensive marketplace offering everything from electronics to fashion, home goods to groceries.
            </p>
            <p className="text-muted-foreground">
              Our journey began when our founder, Kofi Adeyemi, noticed the challenges local businesses faced in
              reaching customers beyond their immediate vicinity. With a background in technology and a passion for
              supporting local commerce, Kofi assembled a team of like-minded individuals to build a platform that would
              empower sellers and provide customers with access to a wide range of products.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-muted-foreground">
              At Benin Market, our mission is to create a thriving digital marketplace that empowers local businesses,
              provides customers with access to quality products, and contributes to the economic development of Benin
              and the broader West African region. We believe in fair trade, transparent business practices, and
              building lasting relationships between sellers and customers.
            </p>
          </section>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-12">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">5,000+</div>
                <p className="text-muted-foreground">Active Sellers</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">50,000+</div>
                <p className="text-muted-foreground">Products Available</p>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-4xl font-bold text-primary mb-2">200,000+</div>
                <p className="text-muted-foreground">Happy Customers</p>
              </CardContent>
            </Card>
          </div>

          <section>
            <h2 className="text-2xl font-bold mb-4">Our Team</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="relative w-32 h-32 mx-auto rounded-full overflow-hidden mb-4">
                  <Image src="/images/team-member-1.jpg" alt="Kofi Adeyemi" fill className="object-cover" />
                </div>
                <h3 className="font-bold">Kofi Adeyemi</h3>
                <p className="text-sm text-muted-foreground">Founder & CEO</p>
              </div>

              <div className="text-center">
                <div className="relative w-32 h-32 mx-auto rounded-full overflow-hidden mb-4">
                  <Image src="/images/team-member-2.jpg" alt="Amina Diallo" fill className="object-cover" />
                </div>
                <h3 className="font-bold">Amina Diallo</h3>
                <p className="text-sm text-muted-foreground">Chief Operations Officer</p>
              </div>

              <div className="text-center">
                <div className="relative w-32 h-32 mx-auto rounded-full overflow-hidden mb-4">
                  <Image src="/images/team-member-3.jpg" alt="David Okafor" fill className="object-cover" />
                </div>
                <h3 className="font-bold">David Okafor</h3>
                <p className="text-sm text-muted-foreground">Chief Technology Officer</p>
              </div>
            </div>
          </section>

          <section className="bg-muted p-6 rounded-lg">
            <h2 className="text-2xl font-bold mb-4">Join Our Community</h2>
            <p className="mb-6">
              Whether you're a seller looking to expand your reach or a customer searching for quality products, Benin
              Market welcomes you to our growing community.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild>
                <Link href="/account/seller">Become a Seller</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
}

