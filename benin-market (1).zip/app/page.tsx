import { Button } from "@/components/ui/button"
import FeaturedCategories from "@/components/featured-categories"
import ProductGrid from "@/components/product-grid"
import HeroBanner from "@/components/hero-banner"
import ChatbotBubble from "@/components/chatbot-bubble"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-8">
      <HeroBanner />

      <section className="my-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold">Featured Categories</h2>
          <Button variant="outline">View All</Button>
        </div>
        <FeaturedCategories />
      </section>

      <section className="my-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold">Popular Products</h2>
          <Button variant="outline">View All</Button>
        </div>
        <ProductGrid />
      </section>

      <ChatbotBubble />
    </div>
  )
}

