import { redirect } from "next/navigation"

export default function AccountPage() {
  // In a real app, this would check if the user is authenticated
  // For now, we'll just redirect to the dashboard
  redirect("/dashboard")
}

