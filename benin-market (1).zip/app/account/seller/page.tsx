import type { Metadata } from "next"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import SellerRegistrationForm from "@/components/seller-registration-form"
import SellerBenefits from "@/components/seller-benefits"

export const metadata: Metadata = {
  title: "Become a Seller | Benin Market",
  description: "Start selling your products on Benin Market",
}

export default function SellerPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Become a Seller on Benin Market</h1>
          <p className="text-muted-foreground">Reach thousands of customers and grow your business</p>
        </div>

        <Tabs defaultValue="register" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="register">Register as Seller</TabsTrigger>
            <TabsTrigger value="benefits">Seller Benefits</TabsTrigger>
          </TabsList>

          <TabsContent value="register">
            <Card>
              <CardHeader>
                <CardTitle>Seller Registration</CardTitle>
                <CardDescription>Fill out the form below to start selling on Benin Market</CardDescription>
              </CardHeader>
              <CardContent>
                <SellerRegistrationForm />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="benefits">
            <SellerBenefits />
          </TabsContent>
        </Tabs>

        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground mb-4">
            Already have a seller account?{" "}
            <Link href="/auth/login" className="text-primary hover:underline">
              Sign in
            </Link>
          </p>
          <Button variant="outline" asChild>
            <Link href="/">Back to Home</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

