import Link from "next/link"
import { notFound } from "next/navigation"
import { ChevronLeft, Package, Truck, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import OrderTimeline from "@/components/dashboard/order-timeline"

// This would normally come from a database or API
const orders = [
  {
    id: "1",
    orderNumber: "BM78945612",
    date: "March 15, 2023",
    total: 129.99,
    status: "delivered",
    items: [
      {
        id: 1,
        name: "Wireless Bluetooth Earbuds",
        price: 29.99,
        quantity: 1,
        image: "/placeholder.svg?height=300&width=300",
      },
      {
        id: 2,
        name: "Men's Casual T-Shirt",
        price: 19.99,
        quantity: 2,
        image: "/placeholder.svg?height=300&width=300",
      },
      {
        id: 3,
        name: "Stainless Steel Water Bottle",
        price: 15.99,
        quantity: 1,
        image: "/placeholder.svg?height=300&width=300",
      },
    ],
    shipping: {
      address: "123 Main Street, Cotonou, Littoral, 01 BP 1234, Benin",
      method: "Standard Delivery",
      cost: 5.99,
      trackingNumber: "BM123456789",
    },
    payment: {
      method: "Visa •••• 4242",
      subtotal: 124.0,
      tax: 6.2,
      total: 129.99,
    },
    timeline: [
      { status: "Order Placed", date: "March 15, 2023", time: "10:30 AM" },
      { status: "Payment Confirmed", date: "March 15, 2023", time: "10:35 AM" },
      { status: "Processing", date: "March 16, 2023", time: "09:15 AM" },
      { status: "Shipped", date: "March 17, 2023", time: "02:45 PM" },
      { status: "Delivered", date: "March 20, 2023", time: "11:20 AM" },
    ],
  },
  {
    id: "2",
    orderNumber: "BM78945613",
    date: "April 2, 2023",
    total: 59.99,
    status: "shipped",
    items: [
      {
        id: 7,
        name: "Bluetooth Portable Speaker",
        price: 39.99,
        quantity: 1,
        image: "/placeholder.svg?height=300&width=300",
      },
      {
        id: 4,
        name: "Smartphone Stand Holder",
        price: 9.99,
        quantity: 2,
        image: "/placeholder.svg?height=300&width=300",
      },
    ],
    shipping: {
      address: "456 Business Avenue, Cotonou, Littoral, 01 BP 5678, Benin",
      method: "Express Delivery",
      cost: 12.99,
      trackingNumber: "BM987654321",
    },
    payment: {
      method: "MTN Mobile Money •••• 7890",
      subtotal: 59.97,
      tax: 3.0,
      total: 59.99,
    },
    timeline: [
      { status: "Order Placed", date: "April 2, 2023", time: "03:45 PM" },
      { status: "Payment Confirmed", date: "April 2, 2023", time: "03:50 PM" },
      { status: "Processing", date: "April 3, 2023", time: "10:30 AM" },
      { status: "Shipped", date: "April 4, 2023", time: "09:15 AM" },
    ],
  },
]

export default function OrderDetailPage({ params }: { params: { id: string } }) {
  const order = orders.find((o) => o.id === params.id)

  if (!order) {
    notFound()
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-5 w-5 text-yellow-500" />
      case "processing":
        return <Package className="h-5 w-5 text-blue-500" />
      case "shipped":
        return <Truck className="h-5 w-5 text-purple-500" />
      case "delivered":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "cancelled":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      default:
        return <Package className="h-5 w-5" />
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Button variant="outline" asChild className="mb-4">
          <Link href="/dashboard" className="flex items-center">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Link>
        </Button>

        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Order #{order.orderNumber}</h1>
            <p className="text-muted-foreground">Placed on {order.date}</p>
          </div>

          <Badge className="w-fit flex items-center gap-1 px-3 py-1">
            {getStatusIcon(order.status)}
            <span className="capitalize">{order.status}</span>
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {order.items.map((item) => (
                  <div key={item.id} className="flex flex-col sm:flex-row gap-4 py-4 border-b last:border-0">
                    <div className="w-20 h-20 bg-muted rounded">
                      <img
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex-1">
                      <h3 className="font-medium">{item.name}</h3>
                      <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                    </div>

                    <div className="text-right">
                      <p className="font-medium">${item.price.toFixed(2)}</p>
                      <p className="text-sm text-muted-foreground">
                        Subtotal: ${(item.price * item.quantity).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Order Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <OrderTimeline timeline={order.timeline} />
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Subtotal</span>
                    <span>${order.payment.subtotal.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-sm">
                    <span>Shipping</span>
                    <span>${order.shipping.cost.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-sm">
                    <span>Tax</span>
                    <span>${order.payment.tax.toFixed(2)}</span>
                  </div>
                </div>

                <div className="border-t pt-2">
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>${order.payment.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Shipping Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Delivery Address</h3>
                  <p className="mt-1">{order.shipping.address}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Shipping Method</h3>
                  <p className="mt-1">{order.shipping.method}</p>
                </div>

                {order.shipping.trackingNumber && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Tracking Number</h3>
                    <p className="mt-1">{order.shipping.trackingNumber}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Payment Method</h3>
                  <p className="mt-1">{order.payment.method}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Billing Address</h3>
                  <p className="mt-1">{order.shipping.address}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-col gap-2">
            <Button asChild>
              <Link href="/contact">Need Help?</Link>
            </Button>
            {(order.status === "delivered" || order.status === "shipped") && (
              <Button variant="outline">Download Invoice</Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

