import type { Metadata } from "next"
import DashboardTabs from "@/components/dashboard/dashboard-tabs"
import DashboardHeader from "@/components/dashboard/dashboard-header"

export const metadata: Metadata = {
  title: "Dashboard | Benin Market",
  description: "Manage your account, orders, and preferences",
}

export default function DashboardPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <DashboardHeader />
      <DashboardTabs />
    </div>
  )
}

