import { notFound } from "next/navigation"
import Link from "next/link"
import { ChevronRight, Star, Truck, RotateCcw, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import AddToCartButton from "@/components/add-to-cart-button"
import RelatedProducts from "@/components/related-products"

// Mock data for products - in a real app, this would come from an API
const products = [
  {
    id: 1,
    name: "Wireless Bluetooth Earbuds",
    price: 29.99,
    image: "/placeholder.svg?height=500&width=500",
    category: "Electronics",
    rating: 4.5,
    slug: "wireless-bluetooth-earbuds",
    description:
      "Experience crystal-clear sound with these wireless Bluetooth earbuds. Featuring noise cancellation technology, long battery life, and a comfortable fit, these earbuds are perfect for music lovers on the go.",
    features: [
      "Bluetooth 5.0 connectivity",
      "Active noise cancellation",
      "Up to 8 hours of battery life",
      "IPX5 water resistance",
      "Touch controls",
      "Built-in microphone for calls",
    ],
    specifications: {
      Brand: "TechSound",
      Model: "TS-WBE100",
      Color: "Black",
      "Battery Life": "8 hours (earbuds) + 24 hours (charging case)",
      Connectivity: "Bluetooth 5.0",
      "Water Resistance": "IPX5",
      Weight: "5g per earbud, 45g charging case",
    },
    stock: 15,
    reviews: 128,
  },
]

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = products.find((p) => p.slug === params.slug)

  if (!product) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <nav className="flex items-center text-sm text-muted-foreground mb-6">
        <Link href="/" className="hover:text-primary">
          Home
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <Link href="/products" className="hover:text-primary">
          Products
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <Link href={`/categories/${product.category.toLowerCase()}`} className="hover:text-primary">
          {product.category}
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <span className="text-foreground font-medium truncate">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {/* Product Image */}
        <div className="bg-muted rounded-lg overflow-hidden">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-auto object-contain aspect-square"
          />
        </div>

        {/* Product Details */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">{product.name}</h1>
            <div className="flex items-center mt-2">
              <div className="flex items-center">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating)
                        ? "text-yellow-400 fill-yellow-400"
                        : i < product.rating
                          ? "text-yellow-400 fill-yellow-400"
                          : "text-gray-300"
                    }`}
                  />
                ))}
                <span className="ml-2 text-muted-foreground">
                  {product.rating} ({product.reviews} reviews)
                </span>
              </div>
            </div>
          </div>

          <div className="text-3xl font-bold">${product.price.toFixed(2)}</div>

          <div className="border-t border-b py-4">
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center text-sm">
              <ShieldCheck className="h-5 w-5 mr-2 text-green-500" />
              <span>Authentic product | Secure payment</span>
            </div>

            <div className="flex items-center text-sm">
              <Truck className="h-5 w-5 mr-2 text-blue-500" />
              <span>Free shipping on orders over $50</span>
            </div>

            <div className="flex items-center text-sm">
              <RotateCcw className="h-5 w-5 mr-2 text-orange-500" />
              <span>14-day easy returns</span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <span className={product.stock > 0 ? "text-green-600" : "text-red-600"}>
              {product.stock > 0 ? `In Stock (${product.stock} available)` : "Out of Stock"}
            </span>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <AddToCartButton product={product} />
            <Button variant="outline">Add to Wishlist</Button>
          </div>
        </div>
      </div>

      {/* Product Tabs */}
      <Tabs defaultValue="details" className="mb-12">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="specifications">Specifications</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="p-4 border rounded-md mt-2">
          <h3 className="text-xl font-semibold mb-4">Product Features</h3>
          <ul className="list-disc pl-5 space-y-2">
            {product.features.map((feature, index) => (
              <li key={index}>{feature}</li>
            ))}
          </ul>
        </TabsContent>

        <TabsContent value="specifications" className="p-4 border rounded-md mt-2">
          <h3 className="text-xl font-semibold mb-4">Technical Specifications</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(product.specifications).map(([key, value]) => (
              <div key={key} className="flex border-b pb-2">
                <span className="font-medium w-1/2">{key}:</span>
                <span className="w-1/2">{value}</span>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="reviews" className="p-4 border rounded-md mt-2">
          <div className="text-center py-8">
            <h3 className="text-xl font-semibold mb-2">Customer Reviews</h3>
            <p className="text-muted-foreground mb-4">
              This product has {product.reviews} reviews with an average rating of {product.rating} stars.
            </p>
            <Button>Write a Review</Button>
          </div>
        </TabsContent>
      </Tabs>

      {/* Related Products */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Related Products</h2>
        <RelatedProducts category={product.category} currentProductId={product.id} />
      </section>
    </div>
  )
}

