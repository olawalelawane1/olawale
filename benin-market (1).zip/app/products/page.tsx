import { Suspense } from "react"
import ProductsGrid from "@/components/products-grid"
import ProductsFilter from "@/components/products-filter"
import { Skeleton } from "@/components/ui/skeleton"

export const metadata = {
  title: "Products | Benin Market",
  description: "Browse all products available on Benin Market",
}

export default function ProductsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">All Products</h1>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/4 lg:w-1/5">
          <ProductsFilter />
        </div>

        <div className="md:w-3/4 lg:w-4/5">
          <Suspense fallback={<ProductsGridSkeleton />}>
            <ProductsGrid />
          </Suspense>
        </div>
      </div>
    </div>
  )
}

function ProductsGridSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="space-y-3">
          <Skeleton className="h-[200px] w-full rounded-lg" />
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-1/2" />
          <div className="flex justify-between">
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-9 w-1/3" />
          </div>
        </div>
      ))}
    </div>
  )
}

