import type { Metadata } from "next"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "FAQ | Benin Market",
  description: "Frequently asked questions about Benin Market",
}

export default function FAQPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Frequently Asked Questions</h1>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="shipping">Shipping</TabsTrigger>
          <TabsTrigger value="sellers">Sellers</TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>What is Benin Market?</AccordionTrigger>
                  <AccordionContent>
                    Benin Market is an online marketplace that connects sellers and buyers in Benin and across West
                    Africa. We offer a wide range of products including electronics, fashion, home goods, and more, all
                    available for purchase online with convenient delivery options.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>How do I contact customer support?</AccordionTrigger>
                  <AccordionContent>
                    You can contact our customer support team through several channels: by email at
                    support@beninmarket.com, by phone at +229 123 456 789, or by using the contact form on our Contact
                    Us page. Our support team is available Monday through Friday from 8:00 AM to 6:00 PM, and Saturday
                    from 9:00 AM to 4:00 PM.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>Is Benin Market available in my country?</AccordionTrigger>
                  <AccordionContent>
                    Benin Market primarily serves customers in Benin and neighboring West African countries. We
                    currently offer shipping to Benin, Togo, Nigeria, Ghana, and Côte d'Ivoire. We're continuously
                    expanding our service area, so please check back if your country isn't currently supported.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
                  <AccordionContent>
                    We accept various payment methods including credit/debit cards (Visa, Mastercard), mobile money
                    services (MTN Mobile Money, Moov Money, Orange Money), bank transfers, and cash on delivery (for
                    eligible orders). All online payments are processed securely through our payment partners.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>Is my personal information secure?</AccordionTrigger>
                  <AccordionContent>
                    Yes, we take data security very seriously. All personal information is encrypted and stored
                    securely. We never share your information with third parties without your consent. You can review
                    our Privacy Policy for more details on how we handle your data.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Account Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>How do I create an account?</AccordionTrigger>
                  <AccordionContent>
                    Creating an account is easy! Click on the "Sign Up" button in the top right corner of the website,
                    fill in your details, and follow the verification process. You can also sign up using your Google or
                    Facebook account for faster registration.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>I forgot my password. How do I reset it?</AccordionTrigger>
                  <AccordionContent>
                    If you've forgotten your password, click on the "Login" button, then select "Forgot Password." Enter
                    the email address associated with your account, and we'll send you instructions to reset your
                    password. Be sure to check your spam folder if you don't see the email in your inbox.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>How do I update my account information?</AccordionTrigger>
                  <AccordionContent>
                    You can update your account information by logging in and navigating to the Dashboard. Select the
                    "Account" tab to update your personal information, change your password, or manage your
                    communication preferences.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>Can I have multiple shipping addresses?</AccordionTrigger>
                  <AccordionContent>
                    Yes, you can save multiple shipping addresses in your account. Go to the Dashboard, select the
                    "Addresses" tab, and click "Add New Address." You can set one address as your default, which will be
                    pre-selected during checkout.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>How do I delete my account?</AccordionTrigger>
                  <AccordionContent>
                    If you wish to delete your account, please contact our customer support team. Please note that
                    deleting your account will permanently remove all your data, including order history and saved
                    addresses, and cannot be undone.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="orders">
          <Card>
            <CardHeader>
              <CardTitle>Order Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>How do I place an order?</AccordionTrigger>
                  <AccordionContent>
                    To place an order, browse our products, add items to your cart, and proceed to checkout. Review your
                    order, select your shipping and payment method, and confirm your purchase. You'll receive an order
                    confirmation email once your order is placed.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>How can I track my order?</AccordionTrigger>
                  <AccordionContent>
                    You can track your order by logging into your account and going to the Dashboard. Select the
                    "Orders" tab to view all your orders. Click on a specific order to see its current status and
                    tracking information, if available.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>Can I modify or cancel my order?</AccordionTrigger>
                  <AccordionContent>
                    You can modify or cancel your order only if it hasn't been processed yet. Go to your Dashboard,
                    select the "Orders" tab, find the order you want to modify or cancel, and click on the appropriate
                    option. If the order has already been processed, please contact customer support for assistance.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>What if an item in my order is out of stock?</AccordionTrigger>
                  <AccordionContent>
                    If an item in your order is out of stock, we'll notify you as soon as possible. You'll have the
                    option to wait for the item to be restocked, replace it with a similar item, or receive a refund for
                    that specific item. We strive to keep our inventory information up-to-date, but occasional
                    discrepancies may occur.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>How do I return an item?</AccordionTrigger>
                  <AccordionContent>
                    To return an item, go to your Dashboard, select the "Orders" tab, find the order containing the item
                    you want to return, and click on "Return Item." Follow the instructions to complete the return
                    process. Please note that items must be returned within 14 days of delivery and must be in their
                    original condition with all packaging and tags intact.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipping">
          <Card>
            <CardHeader>
              <CardTitle>Shipping Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>What shipping options are available?</AccordionTrigger>
                  <AccordionContent>
                    We offer several shipping options: Standard Delivery (3-5 business days), Express Delivery (1-2
                    business days), and Local Pickup (available at select locations). Shipping options and costs vary
                    based on your location and the size/weight of your order.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>How much does shipping cost?</AccordionTrigger>
                  <AccordionContent>
                    Shipping costs depend on your location, the shipping method you choose, and the size/weight of your
                    order. Standard Delivery typically costs between $5.99 and $12.99. Express Delivery ranges from
                    $12.99 to $24.99. We offer free Standard Delivery on orders over $50. You can see the exact shipping
                    cost during checkout before completing your purchase.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>How long will it take to receive my order?</AccordionTrigger>
                  <AccordionContent>
                    Delivery times depend on your location and the shipping method you choose. Standard Delivery
                    typically takes 3-5 business days, while Express Delivery takes 1-2 business days. Please note that
                    these are estimated delivery times and may vary due to factors outside our control, such as weather
                    conditions or customs clearance for international orders.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>Do you ship internationally?</AccordionTrigger>
                  <AccordionContent>
                    Yes, we ship to select countries in West Africa, including Togo, Nigeria, Ghana, and Côte d'Ivoire.
                    International shipping costs and delivery times vary by destination. Please note that international
                    orders may be subject to customs duties and taxes, which are the responsibility of the recipient.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>What if my package is damaged or lost?</AccordionTrigger>
                  <AccordionContent>
                    If your package arrives damaged, please take photos of the damaged package and contents, and contact
                    our customer support team within 48 hours of delivery. If your package is lost during transit,
                    please contact us after the estimated delivery date has passed. We'll work with our shipping
                    partners to locate your package or process a replacement/refund.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sellers">
          <Card>
            <CardHeader>
              <CardTitle>Seller Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>How do I become a seller on Benin Market?</AccordionTrigger>
                  <AccordionContent>
                    To become a seller, click on the "Become a Seller" link in the footer or navigate to the Seller
                    Registration page. Complete the application form with your business details and submit the required
                    documentation. Our team will review your application and get back to you within 3-5 business days.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>What are the fees for selling on Benin Market?</AccordionTrigger>
                  <AccordionContent>
                    We charge a commission fee ranging from 5% to 15% depending on the product category. There are no
                    listing fees or monthly subscription fees. Commission fees are deducted from the sale price when an
                    item is sold. You can view our detailed fee structure in the Seller Terms and Conditions.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>How do I manage my inventory and listings?</AccordionTrigger>
                  <AccordionContent>
                    Once approved as a seller, you'll have access to the Seller Dashboard where you can add new
                    products, update existing listings, manage inventory, and track sales. We provide tools to help you
                    manage your store efficiently, including bulk upload options and inventory management features.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>When and how do I get paid?</AccordionTrigger>
                  <AccordionContent>
                    Payments are processed every two weeks for all completed orders (orders that have been delivered and
                    are past the return period). Funds are transferred directly to your registered bank account or
                    mobile money account. You can view your payment history and upcoming payments in the Seller
                    Dashboard.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>How do I handle returns and refunds?</AccordionTrigger>
                  <AccordionContent>
                    When a customer initiates a return, you'll receive a notification in your Seller Dashboard. You can
                    review the return reason and approve or reject the request. If approved, the customer will return
                    the item to you, and you'll need to confirm receipt before the refund is processed. We have a
                    standard 14-day return policy, but sellers can offer extended return periods if desired.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="mt-12 bg-muted p-6 rounded-lg text-center">
        <h2 className="text-xl font-bold mb-4">Still have questions?</h2>
        <p className="mb-6">Our customer support team is here to help you with any questions or concerns.</p>
        <div className="flex justify-center">
          <a
            href="/contact"
            className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
          >
            Contact Us
          </a>
        </div>
      </div>
    </div>
  )
}

