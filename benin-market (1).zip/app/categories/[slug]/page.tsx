import { notFound } from "next/navigation"
import type { Metadata } from "next"
import Link from "next/link"
import { ChevronRight } from "lucide-react"
import ProductsGrid from "@/components/products-grid"
import ProductsFilter from "@/components/products-filter"
import { Suspense } from "react"
import { Skeleton } from "@/components/ui/skeleton"

// This would normally come from a database or API
const categories = [
  {
    id: 1,
    name: "Electronics",
    slug: "electronics",
    description: "Discover the latest electronics including smartphones, laptops, audio devices, and more.",
    image: "/images/categories/electronics.jpg",
  },
  {
    id: 2,
    name: "Fashion",
    slug: "fashion",
    description: "Shop the latest trends in clothing, shoes, and accessories for men, women, and children.",
    image: "/images/categories/fashion.jpg",
  },
  {
    id: 3,
    name: "Home & Garden",
    slug: "home-garden",
    description:
      "Find everything you need for your home, from furniture and decor to kitchen appliances and garden tools.",
    image: "/images/categories/home-garden.jpg",
  },
  {
    id: 4,
    name: "Beauty & Health",
    slug: "beauty-health",
    description: "Explore our selection of beauty products, skincare, haircare, and health essentials.",
    image: "/images/categories/beauty-health.jpg",
  },
  {
    id: 5,
    name: "Phones & Tablets",
    slug: "phones-tablets",
    description: "Browse our collection of smartphones, tablets, and accessories from top brands.",
    image: "/images/categories/phones-tablets.jpg",
  },
  {
    id: 6,
    name: "Groceries",
    slug: "groceries",
    description: "Shop for fresh food, pantry staples, beverages, and household essentials.",
    image: "/images/categories/groceries.jpg",
  },
]

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const category = categories.find((c) => c.slug === params.slug)

  if (!category) {
    return {
      title: "Category Not Found | Benin Market",
      description: "The requested category could not be found.",
    }
  }

  return {
    title: `${category.name} | Benin Market`,
    description: category.description,
  }
}

export default function CategoryPage({ params }: { params: { slug: string } }) {
  const category = categories.find((c) => c.slug === params.slug)

  if (!category) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumbs */}
      <nav className="flex items-center text-sm text-muted-foreground mb-6">
        <Link href="/" className="hover:text-primary">
          Home
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <Link href="/categories" className="hover:text-primary">
          Categories
        </Link>
        <ChevronRight className="h-4 w-4 mx-2" />
        <span className="text-foreground font-medium">{category.name}</span>
      </nav>

      <div className="relative h-[200px] md:h-[300px] rounded-lg overflow-hidden mb-8">
        <img src={category.image || "/placeholder.svg"} alt={category.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center text-white p-6">
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{category.name}</h1>
            <p className="max-w-2xl mx-auto">{category.description}</p>
          </div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/4 lg:w-1/5">
          <ProductsFilter />
        </div>

        <div className="md:w-3/4 lg:w-4/5">
          <Suspense fallback={<ProductsGridSkeleton />}>
            <ProductsGrid />
          </Suspense>
        </div>
      </div>
    </div>
  )
}

function ProductsGridSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="space-y-3">
          <Skeleton className="h-[200px] w-full rounded-lg" />
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-1/2" />
          <div className="flex justify-between">
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-9 w-1/3" />
          </div>
        </div>
      ))}
    </div>
  )
}

