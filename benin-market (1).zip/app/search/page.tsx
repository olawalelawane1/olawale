import { Suspense } from "react"
import type { Metadata } from "next"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"
import ProductsGrid from "@/components/products-grid"
import ProductsFilter from "@/components/products-filter"
import { Skeleton } from "@/components/ui/skeleton"

export const metadata: Metadata = {
  title: "Search | Benin Market",
  description: "Search for products on Benin Market",
}

export default function SearchPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined }
}) {
  const query = typeof searchParams.q === "string" ? searchParams.q : ""

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Search Results</h1>

      <div className="mb-8">
        <form className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" name="q" placeholder="Search for products..." className="pl-8" defaultValue={query} />
          </div>
          <Button type="submit">Search</Button>
        </form>
      </div>

      {query && (
        <p className="mb-6 text-muted-foreground">
          Showing results for: <span className="font-medium text-foreground">"{query}"</span>
        </p>
      )}

      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/4 lg:w-1/5">
          <ProductsFilter />
        </div>

        <div className="md:w-3/4 lg:w-4/5">
          <Suspense fallback={<ProductsGridSkeleton />}>
            <ProductsGrid />
          </Suspense>
        </div>
      </div>
    </div>
  )
}

function ProductsGridSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {Array.from({ length: 12 }).map((_, i) => (
        <div key={i} className="space-y-3">
          <Skeleton className="h-[200px] w-full rounded-lg" />
          <Skeleton className="h-4 w-2/3" />
          <Skeleton className="h-4 w-1/2" />
          <div className="flex justify-between">
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-9 w-1/3" />
          </div>
        </div>
      ))}
    </div>
  )
}

