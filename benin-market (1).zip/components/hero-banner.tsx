import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function HeroBanner() {
  return (
    <div className="relative rounded-lg overflow-hidden">
      <div className="bg-gradient-to-r from-primary/90 to-primary/70 text-primary-foreground">
        <div className="container mx-auto px-4 py-16 md:py-24 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Welcome to Benin Market</h1>
            <p className="text-lg md:text-xl mb-6">
              Discover thousands of products from local sellers. Shop electronics, fashion, home goods, and more at
              competitive prices.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild>
                <Link href="/products">Shop Now</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="/account/seller">Become a Seller</Link>
              </Button>
            </div>
          </div>
          <div className="md:w-1/2 relative">
            <div className="aspect-[16/9] bg-muted rounded-lg overflow-hidden">
              <Image
                src="/images/marketplace.jpg"
                alt="Benin Market Products"
                width={600}
                height={400}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

