import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Users, TrendingUp, Globe, ShieldCheck, HelpCircle } from "lucide-react"

export default function SellerBenefits() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <Users className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Reach Thousands of Customers</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Connect with thousands of potential customers across Benin and beyond. Our platform brings your products
              to a wide audience looking for quality items.
            </CardDescription>
            <ul className="mt-4 space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Access to growing customer base</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Targeted visibility in your product categories</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <TrendingUp className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Grow Your Business</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Scale your business with our powerful selling tools. From inventory management to sales analytics, we
              provide everything you need to succeed.
            </CardDescription>
            <ul className="mt-4 space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Comprehensive seller dashboard</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Sales analytics and performance insights</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <Globe className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Expand Your Reach</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Take your products beyond local markets. Our platform helps you reach customers throughout Benin and
              neighboring countries.
            </CardDescription>
            <ul className="mt-4 space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>National and regional visibility</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Integrated shipping and delivery options</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <ShieldCheck className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Secure Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Focus on your products while we handle payment processing. Our secure payment system ensures you get paid
              promptly and safely.
            </CardDescription>
            <ul className="mt-4 space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Multiple payment method support</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Fraud protection and secure transactions</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <HelpCircle className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Dedicated Support</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Get the help you need when you need it. Our seller support team is ready to assist you with any questions
              or issues.
            </CardDescription>
            <ul className="mt-4 space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Priority seller support</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Seller education and resources</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <TrendingUp className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Competitive Fees</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Our transparent fee structure ensures you maximize your profits while accessing our powerful selling
              platform.
            </CardDescription>
            <ul className="mt-4 space-y-2">
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>Low commission rates starting at 5%</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="h-5 w-5 text-green-500 mr-2 shrink-0" />
                <span>No hidden fees or charges</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="bg-muted p-6 rounded-lg">
        <h3 className="text-xl font-bold mb-4">Seller Success Stories</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <p className="italic">
              "Joining Benin Market transformed my small craft business. I now reach customers across the country and my
              sales have increased by 300% in just six months."
            </p>
            <p className="font-medium">— Marie K., Handcrafted Jewelry Seller</p>
          </div>
          <div className="space-y-2">
            <p className="italic">
              "The seller tools and analytics helped me understand what products sell best. The platform is easy to use
              and the support team is always helpful."
            </p>
            <p className="font-medium">— Thomas A., Electronics Retailer</p>
          </div>
        </div>
      </div>
    </div>
  )
}

