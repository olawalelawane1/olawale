"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useCart } from "@/context/cart-context"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

export default function CartSummary() {
  const { cartItems, subtotal } = useCart()
  const { toast } = useToast()
  const [promoCode, setPromoCode] = useState("")
  const [isApplyingPromo, setIsApplyingPromo] = useState(false)

  // Calculate shipping cost (free shipping over $50)
  const shippingCost = subtotal > 50 ? 0 : 5.99

  // Calculate tax (assume 5% tax rate)
  const taxRate = 0.05
  const taxAmount = subtotal * taxRate

  // Calculate total
  const total = subtotal + shippingCost + taxAmount

  const handleApplyPromo = () => {
    setIsApplyingPromo(true)

    // Simulate API call
    setTimeout(() => {
      setIsApplyingPromo(false)

      if (promoCode.toLowerCase() === "welcome10") {
        toast({
          title: "Promo code applied",
          description: "You received a 10% discount!",
        })
      } else {
        toast({
          title: "Invalid promo code",
          description: "The promo code you entered is invalid or expired.",
          variant: "destructive",
        })
      }
    }, 1000)
  }

  if (cartItems.length === 0) {
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Summary</CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Subtotal ({cartItems.length} items)</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span>Shipping</span>
            <span>
              {shippingCost === 0 ? <span className="text-green-600">Free</span> : `$${shippingCost.toFixed(2)}`}
            </span>
          </div>

          <div className="flex justify-between text-sm">
            <span>Tax (5%)</span>
            <span>${taxAmount.toFixed(2)}</span>
          </div>
        </div>

        <div className="pt-4 border-t">
          <div className="flex justify-between font-bold text-lg">
            <span>Total</span>
            <span>${total.toFixed(2)}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">(Including VAT)</p>
        </div>

        <div className="pt-4">
          <div className="flex gap-2">
            <Input placeholder="Enter promo code" value={promoCode} onChange={(e) => setPromoCode(e.target.value)} />
            <Button variant="outline" onClick={handleApplyPromo} disabled={!promoCode || isApplyingPromo}>
              Apply
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">Try "WELCOME10" for 10% off your first order</p>
        </div>
      </CardContent>

      <CardFooter>
        <Button asChild className="w-full">
          <Link href="/checkout">Proceed to Checkout</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

