import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"

const categories = [
  {
    id: 1,
    name: "Electronics",
    image: "/images/categories/electronics.jpg",
    slug: "electronics",
  },
  {
    id: 2,
    name: "Fashion",
    image: "/images/categories/fashion.jpg",
    slug: "fashion",
  },
  {
    id: 3,
    name: "Home & Garden",
    image: "/images/categories/home-garden.jpg",
    slug: "home-garden",
  },
  {
    id: 4,
    name: "Beauty & Health",
    image: "/images/categories/beauty-health.jpg",
    slug: "beauty-health",
  },
  {
    id: 5,
    name: "Phones & Tablets",
    image: "/images/categories/phones-tablets.jpg",
    slug: "phones-tablets",
  },
  {
    id: 6,
    name: "Groceries",
    image: "/images/categories/groceries.jpg",
    slug: "groceries",
  },
]

export default function FeaturedCategories() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {categories.map((category) => (
        <Link key={category.id} href={`/categories/${category.slug}`}>
          <Card className="overflow-hidden transition-all hover:shadow-md">
            <CardContent className="p-0">
              <div className="aspect-square relative">
                <Image
                  src={category.image || "/placeholder.svg"}
                  alt={category.name}
                  width={200}
                  height={200}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/40 flex items-end">
                  <div className="w-full p-4 text-white font-medium">{category.name}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

