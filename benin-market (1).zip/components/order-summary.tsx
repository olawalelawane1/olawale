"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useCart } from "@/context/cart-context"
import { Separator } from "@/components/ui/separator"

export default function OrderSummary() {
  const { cartItems, subtotal } = useCart()

  // Calculate shipping cost (free shipping over $50)
  const shippingCost = subtotal > 50 ? 0 : 5.99

  // Calculate tax (assume 5% tax rate)
  const taxRate = 0.05
  const taxAmount = subtotal * taxRate

  // Calculate total
  const total = subtotal + shippingCost + taxAmount

  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Summary</CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-2">
          {cartItems.map((item) => (
            <div key={item.id} className="flex justify-between text-sm">
              <span className="flex-1">
                {item.name} <span className="text-muted-foreground">x{item.quantity}</span>
              </span>
              <span>${(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
        </div>

        <Separator />

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Subtotal</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span>Shipping</span>
            <span>
              {shippingCost === 0 ? <span className="text-green-600">Free</span> : `$${shippingCost.toFixed(2)}`}
            </span>
          </div>

          <div className="flex justify-between text-sm">
            <span>Tax (5%)</span>
            <span>${taxAmount.toFixed(2)}</span>
          </div>
        </div>

        <Separator />

        <div className="flex justify-between font-bold">
          <span>Total</span>
          <span>${total.toFixed(2)}</span>
        </div>

        <div className="text-xs text-muted-foreground">
          <p>By placing your order, you agree to our Terms of Service and Privacy Policy.</p>
        </div>
      </CardContent>
    </Card>
  )
}

