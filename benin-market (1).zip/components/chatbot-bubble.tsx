"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { MessageCircle, X, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  text: string
  isUser: boolean
}

export default function ChatbotBubble() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm your Benin Market assistant. How can I help you today?",
      isUser: false,
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [messages])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()

    if (!inputValue.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      isUser: true,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")

    // Simulate bot response
    setTimeout(() => {
      let botResponse = "I'm sorry, I don't understand that query."

      const userInput = inputValue.toLowerCase()

      if (userInput.includes("hello") || userInput.includes("hi")) {
        botResponse = "Hello! How can I assist you with your shopping today?"
      } else if (userInput.includes("phone") || userInput.includes("smartphone")) {
        botResponse =
          "We have a great selection of phones! You can check our Electronics category for the latest smartphones."
      } else if (userInput.includes("clothes") || userInput.includes("fashion")) {
        botResponse = "Check out our Fashion category for the latest trends in clothing, shoes, and accessories!"
      } else if (userInput.includes("price") || userInput.includes("cost")) {
        botResponse =
          "Our products range in price. You can use the filters on our product pages to find items within your budget."
      } else if (userInput.includes("shipping") || userInput.includes("delivery")) {
        botResponse =
          "We offer standard shipping (3-5 business days) and express shipping (1-2 business days) options at checkout."
      } else if (userInput.includes("payment")) {
        botResponse = "We accept credit/debit cards, mobile money, and cash on delivery as payment methods."
      } else if (userInput.includes("return") || userInput.includes("refund")) {
        botResponse =
          "You can return most items within 14 days of delivery. Please check our Returns Policy for more details."
      }

      const botMessage: Message = {
        id: Date.now().toString(),
        text: botResponse,
        isUser: false,
      }

      setMessages((prev) => [...prev, botMessage])
    }, 1000)
  }

  return (
    <>
      {/* Chat bubble button */}
      <Button
        className="fixed bottom-6 right-6 rounded-full h-14 w-14 shadow-lg"
        onClick={() => setIsOpen(!isOpen)}
        aria-label={isOpen ? "Close chat" : "Open chat"}
      >
        {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </Button>

      {/* Chat window */}
      {isOpen && (
        <Card className="fixed bottom-24 right-6 w-80 sm:w-96 h-96 flex flex-col shadow-xl border rounded-lg overflow-hidden">
          <div className="bg-primary text-primary-foreground p-3 flex items-center justify-between">
            <h3 className="font-medium">Benin Market Assistant</h3>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-primary-foreground"
              onClick={() => setIsOpen(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  "max-w-[80%] rounded-lg p-3",
                  message.isUser ? "bg-primary text-primary-foreground ml-auto" : "bg-muted mr-auto",
                )}
              >
                {message.text}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={handleSendMessage} className="p-3 border-t flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Type your message..."
              className="flex-1"
            />
            <Button type="submit" size="icon">
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </Card>
      )}
    </>
  )
}

