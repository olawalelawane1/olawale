"use client"

import { useRef } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import ProductCard from "@/components/product-card"

// Mock data for products - in a real app, this would come from an API
const allProducts = [
  {
    id: 1,
    name: "Wireless Bluetooth Earbuds",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.5,
    slug: "wireless-bluetooth-earbuds",
  },
  {
    id: 2,
    name: "Men's Casual T-Shirt",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.2,
    slug: "mens-casual-tshirt",
  },
  {
    id: 3,
    name: "Stainless Steel Water Bottle",
    price: 15.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Garden",
    rating: 4.7,
    slug: "stainless-steel-water-bottle",
  },
  {
    id: 4,
    name: "Smartphone Stand Holder",
    price: 9.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.3,
    slug: "smartphone-stand-holder",
  },
  {
    id: 7,
    name: "Bluetooth Portable Speaker",
    price: 39.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.8,
    slug: "bluetooth-portable-speaker",
  },
  {
    id: 9,
    name: "Smart Watch",
    price: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.6,
    slug: "smart-watch",
  },
  {
    id: 12,
    name: "Wireless Mouse",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.4,
    slug: "wireless-mouse",
  },
  {
    id: 14,
    name: "Bluetooth Headphones",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.8,
    slug: "bluetooth-headphones",
  },
]

interface RelatedProductsProps {
  category: string
  currentProductId: number
}

export default function RelatedProducts({ category, currentProductId }: RelatedProductsProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  // Filter products by category and exclude current product
  const relatedProducts = allProducts.filter(
    (product) => product.category === category && product.id !== currentProductId,
  )

  const scroll = (direction: "left" | "right") => {
    if (scrollContainerRef.current) {
      const { current } = scrollContainerRef
      const scrollAmount = 320 // Approximate width of a product card + gap

      if (direction === "left") {
        current.scrollBy({ left: -scrollAmount, behavior: "smooth" })
      } else {
        current.scrollBy({ left: scrollAmount, behavior: "smooth" })
      }
    }
  }

  if (relatedProducts.length === 0) {
    return <p>No related products found.</p>
  }

  return (
    <div className="relative">
      <div className="absolute -left-4 top-1/2 transform -translate-y-1/2 z-10">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full bg-background shadow-md"
          onClick={() => scroll("left")}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
      </div>

      <div
        ref={scrollContainerRef}
        className="flex overflow-x-auto gap-6 pb-4 scrollbar-hide"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {relatedProducts.map((product) => (
          <div key={product.id} className="min-w-[250px] max-w-[250px]">
            <ProductCard product={product} />
          </div>
        ))}
      </div>

      <div className="absolute -right-4 top-1/2 transform -translate-y-1/2 z-10">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full bg-background shadow-md"
          onClick={() => scroll("right")}
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}

