"use client"

import { useState } from "react"
import ProductCard from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for products - in a real app, this would come from an API
const allProducts = [
  {
    id: 1,
    name: "Wireless Bluetooth Earbuds",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.5,
    slug: "wireless-bluetooth-earbuds",
  },
  {
    id: 2,
    name: "Men's Casual T-Shirt",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.2,
    slug: "mens-casual-tshirt",
  },
  {
    id: 3,
    name: "Stainless Steel Water Bottle",
    price: 15.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Garden",
    rating: 4.7,
    slug: "stainless-steel-water-bottle",
  },
  {
    id: 4,
    name: "Smartphone Stand Holder",
    price: 9.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.3,
    slug: "smartphone-stand-holder",
  },
  {
    id: 5,
    name: "Women's Running Shoes",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.6,
    slug: "womens-running-shoes",
  },
  {
    id: 6,
    name: "Ceramic Coffee Mug Set",
    price: 24.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Garden",
    rating: 4.4,
    slug: "ceramic-coffee-mug-set",
  },
  {
    id: 7,
    name: "Bluetooth Portable Speaker",
    price: 39.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.8,
    slug: "bluetooth-portable-speaker",
  },
  {
    id: 8,
    name: "Leather Wallet",
    price: 34.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.5,
    slug: "leather-wallet",
  },
  {
    id: 9,
    name: "Smart Watch",
    price: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.6,
    slug: "smart-watch",
  },
  {
    id: 10,
    name: "Yoga Mat",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Sports",
    rating: 4.3,
    slug: "yoga-mat",
  },
  {
    id: 11,
    name: "Kitchen Knife Set",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Garden",
    rating: 4.7,
    slug: "kitchen-knife-set",
  },
  {
    id: 12,
    name: "Wireless Mouse",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.4,
    slug: "wireless-mouse",
  },
  {
    id: 13,
    name: "Women's Handbag",
    price: 45.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.5,
    slug: "womens-handbag",
  },
  {
    id: 14,
    name: "Bluetooth Headphones",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.8,
    slug: "bluetooth-headphones",
  },
  {
    id: 15,
    name: "Desk Lamp",
    price: 24.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Garden",
    rating: 4.2,
    slug: "desk-lamp",
  },
  {
    id: 16,
    name: "Men's Watch",
    price: 129.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.9,
    slug: "mens-watch",
  },
]

export default function ProductsGrid() {
  const [sortBy, setSortBy] = useState("featured")
  const [currentPage, setCurrentPage] = useState(1)
  const productsPerPage = 12

  // Sort products based on selected option
  const sortedProducts = [...allProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "rating":
        return b.rating - a.rating
      default:
        return 0 // featured - keep original order
    }
  })

  // Calculate pagination
  const indexOfLastProduct = currentPage * productsPerPage
  const indexOfFirstProduct = indexOfLastProduct - productsPerPage
  const currentProducts = sortedProducts.slice(indexOfFirstProduct, indexOfLastProduct)
  const totalPages = Math.ceil(sortedProducts.length / productsPerPage)

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <p className="text-muted-foreground">
          Showing {indexOfFirstProduct + 1}-{Math.min(indexOfLastProduct, sortedProducts.length)} of{" "}
          {sortedProducts.length} products
        </p>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Sort by:</span>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="featured">Featured</SelectItem>
              <SelectItem value="price-low">Price: Low to High</SelectItem>
              <SelectItem value="price-high">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {currentProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center mt-8">
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              &lt;
            </Button>

            {Array.from({ length: totalPages }).map((_, index) => (
              <Button
                key={index}
                variant={currentPage === index + 1 ? "default" : "outline"}
                size="icon"
                onClick={() => setCurrentPage(index + 1)}
              >
                {index + 1}
              </Button>
            ))}

            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              &gt;
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

