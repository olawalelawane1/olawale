"use client"

import type React from "react"

import { useState } from "react"
import { CreditCard, Plus, Trash2, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"

interface PaymentMethod {
  id: string
  type: "card" | "mobile_money"
  provider: string
  lastFour: string
  expiryDate?: string
  cardholderName?: string
  isDefault: boolean
}

export default function PaymentMethods() {
  const { toast } = useToast()
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: "1",
      type: "card",
      provider: "Visa",
      lastFour: "4242",
      expiryDate: "12/25",
      cardholderName: "John Doe",
      isDefault: true,
    },
    {
      id: "2",
      type: "mobile_money",
      provider: "MTN Mobile Money",
      lastFour: "7890",
      isDefault: false,
    },
  ])

  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [paymentType, setPaymentType] = useState<"card" | "mobile_money">("card")

  const handleDeletePaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.filter((method) => method.id !== id))
    toast({
      title: "Payment method removed",
      description: "The payment method has been removed from your account.",
    })
  }

  const handleSetDefault = (id: string) => {
    setPaymentMethods(
      paymentMethods.map((method) => ({
        ...method,
        isDefault: method.id === id,
      })),
    )
    toast({
      title: "Default payment method updated",
      description: "Your default payment method has been updated.",
    })
  }

  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)

    if (paymentType === "card") {
      const cardNumber = formData.get("cardNumber") as string
      const lastFour = cardNumber.slice(-4)

      const newCard: PaymentMethod = {
        id: Date.now().toString(),
        type: "card",
        provider: getCardProvider(cardNumber),
        lastFour,
        expiryDate: `${formData.get("expiryMonth")}/${formData.get("expiryYear")}`,
        cardholderName: formData.get("cardholderName") as string,
        isDefault: paymentMethods.length === 0 || formData.get("isDefault") === "on",
      }

      setPaymentMethods([...paymentMethods, newCard])
    } else {
      const phoneNumber = formData.get("phoneNumber") as string
      const lastFour = phoneNumber.slice(-4)

      const newMobileMoney: PaymentMethod = {
        id: Date.now().toString(),
        type: "mobile_money",
        provider: formData.get("provider") as string,
        lastFour,
        isDefault: paymentMethods.length === 0 || formData.get("isDefault") === "on",
      }

      setPaymentMethods([...paymentMethods, newMobileMoney])
    }

    toast({
      title: "Payment method added",
      description: "The new payment method has been added to your account.",
    })

    setIsDialogOpen(false)
  }

  const getCardProvider = (cardNumber: string) => {
    // Simple detection based on first digit
    const firstDigit = cardNumber.charAt(0)
    if (firstDigit === "4") return "Visa"
    if (firstDigit === "5") return "Mastercard"
    if (firstDigit === "3") return "American Express"
    return "Card"
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Payment Methods</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Payment Method
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>Add Payment Method</DialogTitle>
            </DialogHeader>
            <div className="flex space-x-2 mb-4">
              <Button
                variant={paymentType === "card" ? "default" : "outline"}
                onClick={() => setPaymentType("card")}
                className="flex-1"
              >
                Credit/Debit Card
              </Button>
              <Button
                variant={paymentType === "mobile_money" ? "default" : "outline"}
                onClick={() => setPaymentType("mobile_money")}
                className="flex-1"
              >
                Mobile Money
              </Button>
            </div>

            <form onSubmit={handleAddCard} className="space-y-4">
              {paymentType === "card" ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="cardholderName">Cardholder Name</Label>
                    <Input id="cardholderName" name="cardholderName" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Card Number</Label>
                    <Input id="cardNumber" name="cardNumber" placeholder="0000 0000 0000 0000" required />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiryMonth">Expiry Month</Label>
                      <select
                        id="expiryMonth"
                        name="expiryMonth"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        required
                      >
                        {Array.from({ length: 12 }, (_, i) => {
                          const month = i + 1
                          return (
                            <option key={month} value={month.toString().padStart(2, "0")}>
                              {month.toString().padStart(2, "0")}
                            </option>
                          )
                        })}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="expiryYear">Expiry Year</Label>
                      <select
                        id="expiryYear"
                        name="expiryYear"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        required
                      >
                        {Array.from({ length: 10 }, (_, i) => {
                          const year = new Date().getFullYear() + i
                          return (
                            <option key={year} value={year.toString().slice(-2)}>
                              {year}
                            </option>
                          )
                        })}
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="cvc">CVC</Label>
                      <Input id="cvc" name="cvc" placeholder="123" required />
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="provider">Mobile Money Provider</Label>
                    <select
                      id="provider"
                      name="provider"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      required
                    >
                      <option value="MTN Mobile Money">MTN Mobile Money</option>
                      <option value="Moov Money">Moov Money</option>
                      <option value="Orange Money">Orange Money</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phoneNumber">Phone Number</Label>
                    <Input id="phoneNumber" name="phoneNumber" placeholder="+229 97123456" required />
                  </div>
                </>
              )}

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isDefault"
                  name="isDefault"
                  className="rounded border-gray-300"
                  defaultChecked={paymentMethods.length === 0}
                />
                <Label htmlFor="isDefault">Set as default payment method</Label>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Add Payment Method</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {paymentMethods.length === 0 ? (
        <div className="text-center py-12 border rounded-lg">
          <CreditCard className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No payment methods saved</h3>
          <p className="text-muted-foreground mb-4">Add a payment method to make checkout faster</p>
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Payment Method
          </Button>
        </div>
      ) : (
        <div className="space-y-4">
          {paymentMethods.map((method) => (
            <Card key={method.id} className={`overflow-hidden ${method.isDefault ? "border-primary" : ""}`}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex items-center">
                    {method.type === "card" ? (
                      <div className="h-10 w-16 bg-muted rounded flex items-center justify-center mr-4">
                        {method.provider === "Visa" && <span className="font-bold text-blue-600">VISA</span>}
                        {method.provider === "Mastercard" && <span className="font-bold text-red-600">MC</span>}
                        {method.provider !== "Visa" && method.provider !== "Mastercard" && (
                          <CreditCard className="h-6 w-6" />
                        )}
                      </div>
                    ) : (
                      <div className="h-10 w-10 bg-muted rounded-full flex items-center justify-center mr-4">
                        <span className="font-bold text-sm">
                          {method.provider
                            .split(" ")
                            .map((word) => word[0])
                            .join("")}
                        </span>
                      </div>
                    )}

                    <div>
                      <div className="flex items-center">
                        <p className="font-medium">
                          {method.type === "card"
                            ? `${method.provider} •••• ${method.lastFour}`
                            : `${method.provider} •••• ${method.lastFour}`}
                        </p>
                        {method.isDefault && <Badge className="ml-2">Default</Badge>}
                      </div>

                      {method.type === "card" && (
                        <div className="text-sm text-muted-foreground">
                          <p>
                            {method.cardholderName} • Expires {method.expiryDate}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    {!method.isDefault && (
                      <Button variant="ghost" size="sm" onClick={() => handleSetDefault(method.id)}>
                        <Check className="h-4 w-4 mr-1" />
                        Set Default
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeletePaymentMethod(method.id)}
                      disabled={method.isDefault}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="mt-6 border-t pt-6">
        <h3 className="text-lg font-medium mb-4">Payment Security</h3>
        <p className="text-sm text-muted-foreground">
          All payment information is encrypted and securely stored. We use industry-standard security measures to
          protect your payment details. Benin Market never stores your full card details on our servers.
        </p>
      </div>
    </div>
  )
}

