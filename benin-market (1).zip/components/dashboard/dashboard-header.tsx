"use client"

import { useEffect, useState } from "react"
import { User } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

interface UserProfile {
  name: string
  email: string
  memberSince: string
  orderCount: number
}

export default function DashboardHeader() {
  const [profile, setProfile] = useState<UserProfile>({
    name: "Guest User",
    email: "guest@example.com",
    memberSince: new Date().toLocaleDateString(),
    orderCount: 0,
  })

  // In a real app, this would fetch the user profile from an API
  useEffect(() => {
    // Simulate loading user data
    const timeout = setTimeout(() => {
      setProfile({
        name: "John Doe",
        email: "john.doe@example.com",
        memberSince: "January 15, 2023",
        orderCount: 12,
      })
    }, 500)

    return () => clearTimeout(timeout)
  }, [])

  return (
    <Card className="mb-6">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="bg-primary/10 p-4 rounded-full">
            <User className="h-12 w-12 text-primary" />
          </div>

          <div className="flex-1">
            <h1 className="text-2xl font-bold">{profile.name}</h1>
            <p className="text-muted-foreground">{profile.email}</p>
            <div className="flex flex-col sm:flex-row sm:gap-6 mt-2 text-sm">
              <span>Member since: {profile.memberSince}</span>
              <span>Orders: {profile.orderCount}</span>
            </div>
          </div>

          <div className="mt-4 md:mt-0">
            <span className="inline-flex items-center rounded-full bg-green-100 px-3 py-1 text-sm font-medium text-green-800">
              Verified Customer
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

