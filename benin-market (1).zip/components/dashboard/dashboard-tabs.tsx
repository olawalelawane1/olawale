"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import OrderHistory from "@/components/dashboard/order-history"
import AccountSettings from "@/components/dashboard/account-settings"
import SavedAddresses from "@/components/dashboard/saved-addresses"
import PaymentMethods from "@/components/dashboard/payment-methods"
import Wishlist from "@/components/dashboard/wishlist"

export default function DashboardTabs() {
  const [activeTab, setActiveTab] = useState("orders")

  return (
    <Tabs defaultValue="orders" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
      <TabsList className="grid grid-cols-2 md:grid-cols-5 gap-2">
        <TabsTrigger value="orders">Orders</TabsTrigger>
        <TabsTrigger value="account">Account</TabsTrigger>
        <TabsTrigger value="addresses">Addresses</TabsTrigger>
        <TabsTrigger value="payment">Payment</TabsTrigger>
        <TabsTrigger value="wishlist">Wishlist</TabsTrigger>
      </TabsList>

      <Card>
        <TabsContent value="orders" className="p-4">
          <OrderHistory />
        </TabsContent>

        <TabsContent value="account" className="p-4">
          <AccountSettings />
        </TabsContent>

        <TabsContent value="addresses" className="p-4">
          <SavedAddresses />
        </TabsContent>

        <TabsContent value="payment" className="p-4">
          <PaymentMethods />
        </TabsContent>

        <TabsContent value="wishlist" className="p-4">
          <Wishlist />
        </TabsContent>
      </Card>
    </Tabs>
  )
}

