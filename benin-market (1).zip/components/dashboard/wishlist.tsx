"use client"

import { useState, useEffect } from "react"
import { Heart, ShoppingCart, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useCart } from "@/context/cart-context"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"

interface WishlistItem {
  id: number
  name: string
  price: number
  image: string
  category: string
  slug: string
  inStock: boolean
}

export default function Wishlist() {
  const { addToCart } = useCart()
  const { toast } = useToast()
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate API call to fetch wishlist
    const timeout = setTimeout(() => {
      setWishlistItems([
        {
          id: 1,
          name: "Wireless Bluetooth Earbuds",
          price: 29.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Electronics",
          slug: "wireless-bluetooth-earbuds",
          inStock: true,
        },
        {
          id: 7,
          name: "Bluetooth Portable Speaker",
          price: 39.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Electronics",
          slug: "bluetooth-portable-speaker",
          inStock: true,
        },
        {
          id: 5,
          name: "Women's Running Shoes",
          price: 49.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Fashion",
          slug: "womens-running-shoes",
          inStock: false,
        },
      ])
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timeout)
  }, [])

  const handleRemoveFromWishlist = (id: number) => {
    setWishlistItems(wishlistItems.filter((item) => item.id !== id))
    toast({
      title: "Removed from wishlist",
      description: "The item has been removed from your wishlist.",
    })
  }

  const handleAddToCart = (item: WishlistItem) => {
    addToCart(item)
    toast({
      title: "Added to cart",
      description: `${item.name} has been added to your cart.`,
    })
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">My Wishlist</h2>
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">My Wishlist</h2>
        <Button asChild>
          <Link href="/products">Continue Shopping</Link>
        </Button>
      </div>

      {wishlistItems.length === 0 ? (
        <div className="text-center py-12 border rounded-lg">
          <Heart className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">Your wishlist is empty</h3>
          <p className="text-muted-foreground mb-4">Save items you like to your wishlist and revisit them later</p>
          <Button asChild>
            <Link href="/products">Browse Products</Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {wishlistItems.map((item) => (
            <Card key={item.id} className="overflow-hidden">
              <CardContent className="p-0">
                <Link href={`/products/${item.slug}`}>
                  <div className="aspect-square relative">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                    {!item.inStock && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                        <span className="text-white font-medium px-3 py-1 bg-red-500 rounded-full text-sm">
                          Out of Stock
                        </span>
                      </div>
                    )}
                  </div>
                </Link>

                <div className="p-4">
                  <Link href={`/products/${item.slug}`} className="hover:underline">
                    <h3 className="font-medium text-lg line-clamp-1">{item.name}</h3>
                  </Link>
                  <p className="text-sm text-muted-foreground mb-2">{item.category}</p>
                  <div className="flex justify-between items-center">
                    <span className="font-bold">${item.price.toFixed(2)}</span>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={() => handleRemoveFromWishlist(item.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                      <Button size="sm" onClick={() => handleAddToCart(item)} disabled={!item.inStock}>
                        <ShoppingCart className="h-4 w-4 mr-1" />
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

