"use client"

interface TimelineEvent {
  status: string
  date: string
  time: string
}

interface OrderTimelineProps {
  timeline: TimelineEvent[]
}

export default function OrderTimeline({ timeline }: OrderTimelineProps) {
  return (
    <div className="relative">
      <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-muted"></div>

      <div className="space-y-6">
        {timeline.map((event, index) => (
          <div key={index} className="relative pl-10">
            <div className="absolute left-0 top-1 h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
              <div className="h-2 w-2 rounded-full bg-primary"></div>
            </div>

            <div>
              <h3 className="font-medium">{event.status}</h3>
              <p className="text-sm text-muted-foreground">
                {event.date} at {event.time}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

