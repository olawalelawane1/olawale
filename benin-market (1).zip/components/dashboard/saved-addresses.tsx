"use client"

import type React from "react"

import { useState } from "react"
import { MapPin, Plus, Edit, Trash2, Home, Briefcase } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { Badge } from "@/components/ui/badge"

interface Address {
  id: string
  name: string
  street: string
  city: string
  state: string
  postalCode: string
  country: string
  phone: string
  isDefault: boolean
  type: "home" | "work" | "other"
}

export default function SavedAddresses() {
  const { toast } = useToast()
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: "1",
      name: "John Doe",
      street: "123 Main Street",
      city: "Cotonou",
      state: "Littoral",
      postalCode: "01 BP 1234",
      country: "Benin",
      phone: "+229 97123456",
      isDefault: true,
      type: "home",
    },
    {
      id: "2",
      name: "John Doe",
      street: "456 Business Avenue",
      city: "Cotonou",
      state: "Littoral",
      postalCode: "01 BP 5678",
      country: "Benin",
      phone: "+229 97654321",
      isDefault: false,
      type: "work",
    },
  ])

  const [editingAddress, setEditingAddress] = useState<Address | null>(null)
  const [isAddingAddress, setIsAddingAddress] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const handleAddAddress = () => {
    setEditingAddress(null)
    setIsAddingAddress(true)
    setIsDialogOpen(true)
  }

  const handleEditAddress = (address: Address) => {
    setEditingAddress(address)
    setIsAddingAddress(false)
    setIsDialogOpen(true)
  }

  const handleDeleteAddress = (id: string) => {
    setAddresses(addresses.filter((address) => address.id !== id))
    toast({
      title: "Address deleted",
      description: "The address has been removed from your account.",
    })
  }

  const handleSetDefault = (id: string) => {
    setAddresses(
      addresses.map((address) => ({
        ...address,
        isDefault: address.id === id,
      })),
    )
    toast({
      title: "Default address updated",
      description: "Your default shipping address has been updated.",
    })
  }

  const handleSubmitAddress = (e: React.FormEvent) => {
    e.preventDefault()
    const formData = new FormData(e.target as HTMLFormElement)
    const addressData = {
      id: editingAddress?.id || Date.now().toString(),
      name: formData.get("name") as string,
      street: formData.get("street") as string,
      city: formData.get("city") as string,
      state: formData.get("state") as string,
      postalCode: formData.get("postalCode") as string,
      country: formData.get("country") as string,
      phone: formData.get("phone") as string,
      type: formData.get("type") as "home" | "work" | "other",
      isDefault: editingAddress?.isDefault || addresses.length === 0 || formData.get("isDefault") === "on",
    }

    if (isAddingAddress) {
      setAddresses([...addresses, addressData])
      toast({
        title: "Address added",
        description: "The new address has been added to your account.",
      })
    } else {
      setAddresses(addresses.map((address) => (address.id === editingAddress?.id ? addressData : address)))
      toast({
        title: "Address updated",
        description: "The address has been updated successfully.",
      })
    }

    setIsDialogOpen(false)
  }

  const getAddressTypeIcon = (type: Address["type"]) => {
    switch (type) {
      case "home":
        return <Home className="h-4 w-4" />
      case "work":
        return <Briefcase className="h-4 w-4" />
      default:
        return <MapPin className="h-4 w-4" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Saved Addresses</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddAddress}>
              <Plus className="mr-2 h-4 w-4" />
              Add New Address
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>{isAddingAddress ? "Add New Address" : "Edit Address"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmitAddress} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" name="name" defaultValue={editingAddress?.name || ""} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="street">Street Address</Label>
                <Input id="street" name="street" defaultValue={editingAddress?.street || ""} required />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City</Label>
                  <Input id="city" name="city" defaultValue={editingAddress?.city || ""} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State/Province</Label>
                  <Input id="state" name="state" defaultValue={editingAddress?.state || ""} required />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="postalCode">Postal Code</Label>
                  <Input id="postalCode" name="postalCode" defaultValue={editingAddress?.postalCode || ""} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country">Country</Label>
                  <Input id="country" name="country" defaultValue={editingAddress?.country || "Benin"} required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" name="phone" type="tel" defaultValue={editingAddress?.phone || ""} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="type">Address Type</Label>
                <select
                  id="type"
                  name="type"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  defaultValue={editingAddress?.type || "home"}
                >
                  <option value="home">Home</option>
                  <option value="work">Work</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="isDefault"
                  name="isDefault"
                  className="rounded border-gray-300"
                  defaultChecked={editingAddress?.isDefault || addresses.length === 0}
                />
                <Label htmlFor="isDefault">Set as default address</Label>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">{isAddingAddress ? "Add Address" : "Save Changes"}</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {addresses.length === 0 ? (
        <div className="text-center py-12 border rounded-lg">
          <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No addresses saved</h3>
          <p className="text-muted-foreground mb-4">Add a shipping address to make checkout faster</p>
          <Button onClick={handleAddAddress}>
            <Plus className="mr-2 h-4 w-4" />
            Add New Address
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {addresses.map((address) => (
            <Card key={address.id} className={`overflow-hidden ${address.isDefault ? "border-primary" : ""}`}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center">
                    <Badge variant="outline" className="flex items-center gap-1">
                      {getAddressTypeIcon(address.type)}
                      <span className="capitalize">{address.type}</span>
                    </Badge>
                    {address.isDefault && <Badge className="ml-2">Default</Badge>}
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm" onClick={() => handleEditAddress(address)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteAddress(address.id)}
                      disabled={address.isDefault}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-1">
                  <p className="font-medium">{address.name}</p>
                  <p>{address.street}</p>
                  <p>
                    {address.city}, {address.state} {address.postalCode}
                  </p>
                  <p>{address.country}</p>
                  <p className="text-sm text-muted-foreground mt-2">{address.phone}</p>
                </div>

                {!address.isDefault && (
                  <Button variant="outline" size="sm" className="mt-4" onClick={() => handleSetDefault(address.id)}>
                    Set as Default
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

