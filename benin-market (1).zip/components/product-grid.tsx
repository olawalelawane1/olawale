import ProductCard from "@/components/product-card"

// Mock data for products
const products = [
  {
    id: 1,
    name: "Wireless Bluetooth Earbuds",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.5,
    slug: "wireless-bluetooth-earbuds",
  },
  {
    id: 2,
    name: "Men's Casual T-Shirt",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.2,
    slug: "mens-casual-tshirt",
  },
  {
    id: 3,
    name: "Stainless Steel Water Bottle",
    price: 15.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Garden",
    rating: 4.7,
    slug: "stainless-steel-water-bottle",
  },
  {
    id: 4,
    name: "Smartphone Stand Holder",
    price: 9.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.3,
    slug: "smartphone-stand-holder",
  },
  {
    id: 5,
    name: "Women's Running Shoes",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.6,
    slug: "womens-running-shoes",
  },
  {
    id: 6,
    name: "Ceramic Coffee Mug Set",
    price: 24.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Home & Garden",
    rating: 4.4,
    slug: "ceramic-coffee-mug-set",
  },
  {
    id: 7,
    name: "Bluetooth Portable Speaker",
    price: 39.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Electronics",
    rating: 4.8,
    slug: "bluetooth-portable-speaker",
  },
  {
    id: 8,
    name: "Leather Wallet",
    price: 34.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Fashion",
    rating: 4.5,
    slug: "leather-wallet",
  },
]

export default function ProductGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}

