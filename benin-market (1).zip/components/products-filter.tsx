"use client"

import { useState } from "react"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const categories = [
  { id: "electronics", label: "Electronics" },
  { id: "fashion", label: "Fashion" },
  { id: "home-garden", label: "Home & Garden" },
  { id: "beauty-health", label: "Beauty & Health" },
  { id: "sports", label: "Sports & Outdoors" },
  { id: "toys", label: "Toys & Games" },
  { id: "groceries", label: "Groceries" },
  { id: "books", label: "Books & Media" },
]

const ratings = [
  { id: "4-up", label: "4 Stars & Up" },
  { id: "3-up", label: "3 Stars & Up" },
  { id: "2-up", label: "2 Stars & Up" },
  { id: "1-up", label: "1 Star & Up" },
]

export default function ProductsFilter() {
  const [priceRange, setPriceRange] = useState([0, 200])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedRatings, setSelectedRatings] = useState<string[]>([])

  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, categoryId])
    } else {
      setSelectedCategories(selectedCategories.filter((id) => id !== categoryId))
    }
  }

  const handleRatingChange = (ratingId: string, checked: boolean) => {
    if (checked) {
      setSelectedRatings([...selectedRatings, ratingId])
    } else {
      setSelectedRatings(selectedRatings.filter((id) => id !== ratingId))
    }
  }

  const handlePriceChange = (values: number[]) => {
    setPriceRange(values)
  }

  const handleClearFilters = () => {
    setPriceRange([0, 200])
    setSelectedCategories([])
    setSelectedRatings([])
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex justify-between items-center">
          Filters
          <Button variant="ghost" size="sm" onClick={handleClearFilters}>
            Clear All
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <Accordion type="multiple" defaultValue={["price", "categories", "ratings"]}>
          <AccordionItem value="price">
            <AccordionTrigger>Price Range</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <Slider
                  defaultValue={[0, 200]}
                  min={0}
                  max={200}
                  step={5}
                  value={priceRange}
                  onValueChange={handlePriceChange}
                />
                <div className="flex items-center justify-between">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="categories">
            <AccordionTrigger>Categories</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`category-${category.id}`}
                      checked={selectedCategories.includes(category.id)}
                      onCheckedChange={(checked) => handleCategoryChange(category.id, checked as boolean)}
                    />
                    <label
                      htmlFor={`category-${category.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {category.label}
                    </label>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="ratings">
            <AccordionTrigger>Ratings</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2">
                {ratings.map((rating) => (
                  <div key={rating.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`rating-${rating.id}`}
                      checked={selectedRatings.includes(rating.id)}
                      onCheckedChange={(checked) => handleRatingChange(rating.id, checked as boolean)}
                    />
                    <label
                      htmlFor={`rating-${rating.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {rating.label}
                    </label>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <Button className="w-full">Apply Filters</Button>
      </CardContent>
    </Card>
  )
}

