"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function SellerRegistrationForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Registration submitted",
        description:
          "Your seller application has been submitted successfully. We'll review it and get back to you soon.",
      })
      router.push("/dashboard")
    }, 1500)
  }

  const nextStep = () => {
    setCurrentStep(currentStep + 1)
  }

  const prevStep = () => {
    setCurrentStep(currentStep - 1)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {currentStep === 1 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Business Information</h3>

          <div className="space-y-2">
            <Label htmlFor="businessName">Business Name</Label>
            <Input id="businessName" name="businessName" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="businessType">Business Type</Label>
            <select
              id="businessType"
              name="businessType"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              required
            >
              <option value="">Select business type</option>
              <option value="individual">Individual/Sole Proprietor</option>
              <option value="partnership">Partnership</option>
              <option value="corporation">Corporation</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="businessDescription">Business Description</Label>
            <Textarea
              id="businessDescription"
              name="businessDescription"
              placeholder="Tell us about your business and the products you sell"
              rows={4}
              required
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="businessPhone">Business Phone</Label>
              <Input id="businessPhone" name="businessPhone" type="tel" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="businessEmail">Business Email</Label>
              <Input id="businessEmail" name="businessEmail" type="email" required />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="businessAddress">Business Address</Label>
            <Input id="businessAddress" name="businessAddress" required />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Input id="city" name="city" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="state">State/Province</Label>
              <Input id="state" name="state" required />
            </div>

            <div className="space-y-2">
              <Label htmlFor="postalCode">Postal Code</Label>
              <Input id="postalCode" name="postalCode" required />
            </div>
          </div>

          <div className="pt-4 flex justify-end">
            <Button type="button" onClick={nextStep}>
              Next Step
            </Button>
          </div>
        </div>
      )}

      {currentStep === 2 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Product Information</h3>

          <div className="space-y-2">
            <Label htmlFor="productCategories">Product Categories</Label>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="electronics" name="categories[]" value="electronics" />
                <Label htmlFor="electronics" className="font-normal">
                  Electronics
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="fashion" name="categories[]" value="fashion" />
                <Label htmlFor="fashion" className="font-normal">
                  Fashion
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="home" name="categories[]" value="home" />
                <Label htmlFor="home" className="font-normal">
                  Home & Garden
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="beauty" name="categories[]" value="beauty" />
                <Label htmlFor="beauty" className="font-normal">
                  Beauty & Health
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="sports" name="categories[]" value="sports" />
                <Label htmlFor="sports" className="font-normal">
                  Sports & Outdoors
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="other" name="categories[]" value="other" />
                <Label htmlFor="other" className="font-normal">
                  Other
                </Label>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="productDescription">Product Description</Label>
            <Textarea
              id="productDescription"
              name="productDescription"
              placeholder="Describe the types of products you plan to sell"
              rows={4}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="estimatedProducts">Estimated Number of Products</Label>
            <select
              id="estimatedProducts"
              name="estimatedProducts"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              required
            >
              <option value="">Select range</option>
              <option value="1-10">1-10 products</option>
              <option value="11-50">11-50 products</option>
              <option value="51-100">51-100 products</option>
              <option value="101-500">101-500 products</option>
              <option value="500+">500+ products</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="shippingMethods">Shipping Methods</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="standard" name="shipping[]" value="standard" />
                <Label htmlFor="standard" className="font-normal">
                  Standard Shipping
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="express" name="shipping[]" value="express" />
                <Label htmlFor="express" className="font-normal">
                  Express Shipping
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="pickup" name="shipping[]" value="pickup" />
                <Label htmlFor="pickup" className="font-normal">
                  Local Pickup
                </Label>
              </div>
            </div>
          </div>

          <div className="pt-4 flex justify-between">
            <Button type="button" variant="outline" onClick={prevStep}>
              Previous Step
            </Button>
            <Button type="button" onClick={nextStep}>
              Next Step
            </Button>
          </div>
        </div>
      )}

      {currentStep === 3 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Legal Information</h3>

          <div className="space-y-2">
            <Label htmlFor="taxId">Tax ID / Business Registration Number</Label>
            <Input id="taxId" name="taxId" required />
          </div>

          <div className="space-y-2">
            <Label htmlFor="idType">ID Type</Label>
            <select
              id="idType"
              name="idType"
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              required
            >
              <option value="">Select ID type</option>
              <option value="passport">Passport</option>
              <option value="nationalId">National ID</option>
              <option value="driverLicense">Driver's License</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="idNumber">ID Number</Label>
            <Input id="idNumber" name="idNumber" required />
          </div>

          <div className="space-y-2">
            <Label>Document Upload</Label>
            <p className="text-sm text-muted-foreground mb-2">
              Please upload a copy of your business registration and ID document
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="businessDoc">Business Registration</Label>
                <Input id="businessDoc" name="businessDoc" type="file" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="idDoc">ID Document</Label>
                <Input id="idDoc" name="idDoc" type="file" />
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-4">
            <div className="flex items-start space-x-2">
              <input type="checkbox" id="termsAgree" name="termsAgree" className="mt-1" required />
              <Label htmlFor="termsAgree" className="font-normal text-sm">
                I agree to the Benin Market Seller Terms and Conditions, including the Privacy Policy and Fee Schedule.
                I understand that my information will be verified before my seller account is approved.
              </Label>
            </div>
          </div>

          <div className="pt-4 flex justify-between">
            <Button type="button" variant="outline" onClick={prevStep}>
              Previous Step
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Submitting..." : "Submit Application"}
            </Button>
          </div>
        </div>
      )}
    </form>
  )
}

